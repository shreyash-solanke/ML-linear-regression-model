Please install numpy and matplotlib libraries before running this .py file.

To run, use "python3 hw4.py"

Function calls are written according to the questions. You can comment out the function calls in the "__main__" method to avoid plotting all graphs.

